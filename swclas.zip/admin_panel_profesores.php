<?php
require_once("./Model/conexion.php");
require_once 'Views/admin_panel_profesores.view.php';


?>