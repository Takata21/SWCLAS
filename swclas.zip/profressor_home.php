<?php
echo 'Estoy en el home de professor';

?>