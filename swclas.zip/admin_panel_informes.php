<?php
require_once 'Views/admin_panel_informes.view.php';


?>