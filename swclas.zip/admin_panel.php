<?php

require_once 'Views/admin_panel.view.php';
?>