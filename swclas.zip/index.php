<?php

session_start();
if(isset($_SESSION['usuario'])){
    header('Location: home.php');
    die();
}else{
    header('Location: login.php');
}
?>
