<?php

define ('DB_HOST','localhost');
define('DB_USUARIO','root');
define('DB_PASS','');
define('DB_NOMBRE','swclass');
define('DB_CHARSET','utf8');

define('DB_DNS','mysql:dbname=swclass;host=127.0.0.1');







?>