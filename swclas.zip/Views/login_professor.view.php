<?php
echo 'estoy en el panel de profesor';

?>